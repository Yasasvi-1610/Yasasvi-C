/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define  state main
int state()
{
    printf("Yasasvi\n");
    int a,b;
    printf("enter a,b values");
    scanf("%d%d",&a,&b);
    printf("difference=%d",a+~b+1);
}
